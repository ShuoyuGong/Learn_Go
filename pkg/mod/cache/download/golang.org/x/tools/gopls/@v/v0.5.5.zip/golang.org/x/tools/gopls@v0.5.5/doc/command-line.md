# Command line

## Flags

## Commands

### Serve

### Check

### Format

<!--- TODO: command line
detailed command line instructions, use cases and flags
--->